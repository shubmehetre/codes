"""Itertools exercises"""


def total_length():
    """Return the total number of items in all given iterables."""


def lstrip():
    """Return iterable with strip_value items removed from beginning."""
